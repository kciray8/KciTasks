package com.kciray.play;

public class Product {
    String name;
    Double price;
}
