package com.kciray.play;

import org.h2.tools.Server;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ImportResource;
import org.springframework.jdbc.BadSqlGrammarException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.interceptor.TransactionAttributeSourceAdvisor;
import org.springframework.transaction.interceptor.TransactionInterceptor;

import javax.sql.DataSource;
import java.util.List;
import java.util.Map;

@SpringBootApplication
@ImportResource("beans.xml")
public class Main implements CommandLineRunner {
    public static void main(String[] args) {
        SpringApplication.run(Main.class);
    }

    @Autowired
    ApplicationContext context;

    public void run(String... strings) throws Exception {
        ProductUtils productUtils = context.getBean(ProductUtils.class);

        try{
            productUtils.addTwo();
        }catch (BadSqlGrammarException gr){
            System.out.println(gr);
        }

        productUtils.print();

        //ProductUtils$$EnhancerBySpringCGLIB$$858f5050 OR ProductUtils
        //Transactions work on Spring AOP
        System.out.println(productUtils.getClass());
    }
}
