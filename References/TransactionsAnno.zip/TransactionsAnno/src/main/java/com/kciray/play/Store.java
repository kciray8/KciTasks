package com.kciray.play;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Store {
    @Id
    @GeneratedValue
    Long id;

    String address;
}
