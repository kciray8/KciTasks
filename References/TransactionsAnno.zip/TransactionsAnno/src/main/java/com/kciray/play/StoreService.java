package com.kciray.play;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StoreService {
    @Autowired
    StoreRepo storeRepo;

    public void addStores(){
        Store store = new Store();
        store.address = "Aaaa";
        storeRepo.save(store);
    }

    public void print(){
        for(Store store: storeRepo.findAll()){
            System.out.println("Store: " + store.id + " " + store.address);
        }
    }
}
