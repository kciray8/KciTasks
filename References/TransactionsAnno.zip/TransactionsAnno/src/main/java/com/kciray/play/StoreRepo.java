package com.kciray.play;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
//@Transactional(propagation = Propagation.MANDATORY)
public interface StoreRepo extends CrudRepository<Store, Long>{

}
