package com.kciray.play;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

@EnableJpaRepositories
@Configuration
public class Config {
    //HibernateTransactionManager

    //Additional info:
    //We also have JpaTransactionManager, WebLogicJtaTransactionManager, JtaTransactionManager (Java EE) and many others

    ///Google JpaTransactionManager vs HibernateTransactionManager

    @Bean
    public DataSource dataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("org.h2.Driver");
        dataSource.setUrl("jdbc:h2:./test;DB_CLOSE_ON_EXIT=FALSE");
        dataSource.setUsername("sa");
        dataSource.setPassword("sa");

        return dataSource;
    }

    /*@Bean
    public PlatformTransactionManager transactionManager(
            EntityManagerFactory
                    entityManagerFactory
    ) {
        return new JpaTransactionManager(entityManagerFactory);
    }*/
}
