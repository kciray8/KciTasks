INSERT INTO Product VALUES('Milk', 3.5)
INSERT INTO Product VALUES('Eggs', 6)