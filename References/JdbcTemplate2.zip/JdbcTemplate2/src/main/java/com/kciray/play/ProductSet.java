package com.kciray.play;

import java.util.ArrayList;
import java.util.List;

public class ProductSet {
    public List<Product> products = new ArrayList<>();
}
